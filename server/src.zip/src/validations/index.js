module.exports = {
  bookingValidation: require("./booking.validation"),
  corporateValidation: require("./corporate.validation"),
  userValidation: require("./user.validation"),
};
