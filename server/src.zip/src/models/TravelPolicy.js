const mongoose = require('mongoose');

const travelPolicySchema = new mongoose.Schema({
  corporateId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Corporate',
    required: true,
    unique: true,
    index: true
  },
  policyName: {
    type: String,
    required: true,
    trim: true
  },
  
  // Flight Policies
  flightPolicy: {
    allowedCabinClasses: [{
      type: String,
      enum: ['Economy', 'Premium Economy', 'Business', 'First']
    }],
    preferredAirlines: [String],
    restrictedAirlines: [String],
    advanceBookingDays: {
      domestic: { type: Number, default: 0 },
      international: { type: Number, default: 7 }
    },
    maxFareAmount: {
      domestic: { type: Number, default: 0 },
      international: { type: Number, default: 0 }
    },
    allowDirectFlightsOnly: {
      type: Boolean,
      default: false
    },
    allowAncillaryServices: {
      meals: { type: Boolean, default: true },
      baggage: { type: Boolean, default: true },
      seats: { type: Boolean, default: true }
    }
  },
  
  // Hotel Policies
  hotelPolicy: {
    allowedStarRatings: [{
      type: Number,
      min: 1,
      max: 5
    }],
    maxRoomRate: {
      type: Number,
      default: 0
    },
    allowedCities: [String],
    preferredHotelChains: [String],
    maxNightsPerBooking: {
      type: Number,
      default: 0
    }
  },
  
  // Approval Policies
  approvalPolicy: {
    requiresApproval: {
      type: Boolean,
      default: true
    },
    approvalThreshold: {
      type: Number,
      default: 0
    },
    approvalLevels: [{
      level: Number,
      role: String,
      amount: Number
    }],
    autoApprovalForAmountBelow: {
      type: Number,
      default: 0
    }
  },
  
  // General Policies
  generalPolicy: {
    allowWeekendTravel: {
      type: Boolean,
      default: true
    },
    requirePurposeOfTravel: {
      type: Boolean,
      default: true
    },
    allowSameDayBooking: {
      type: Boolean,
      default: false
    },
    cancellationAllowed: {
      type: Boolean,
      default: true
    },
    cancellationHoursBefore: {
      type: Number,
      default: 24
    },
    amendmentAllowed: {
      type: Boolean,
      default: true
    }
  },
  
  isActive: {
    type: Boolean,
    default: true
  },
  
  effectiveFrom: Date,
  effectiveTo: Date,
  
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  updatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('TravelPolicy', travelPolicySchema);
