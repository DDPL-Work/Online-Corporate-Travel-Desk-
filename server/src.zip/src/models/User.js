const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  corporateId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Corporate',
    required: true,
    index: true
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email']
  },
  password: {
    type: String,
    select: false,
    minlength: 8
  },
  name: {
    firstName: { 
      type: String, 
      required: [true, 'First name is required'],
      trim: true 
    },
    lastName: { 
      type: String, 
      required: [true, 'Last name is required'],
      trim: true 
    }
  },
  mobile: {
    type: String,
    trim: true
  },
  role: {
    type: String,
    enum: ['employee', 'travelAdmin', 'manager', 'superAdmin'],
    default: 'employee',
    index: true
  },
  department: {
    type: String,
    trim: true
  },
  employeeId: {
    type: String,
    trim: true
  },
  designation: {
    type: String,
    trim: true
  },
  managerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  ssoProvider: {
    type: String,
    enum: ['google', 'microsoft', 'zoho', null]
  },
  ssoId: {
    type: String,
    sparse: true
  },
  profilePicture: String,
  travellerDetails: {
    dateOfBirth: Date,
    gender: { 
      type: String, 
      enum: ['Male', 'Female', 'Other'] 
    },
    nationality: {
      type: String,
      default: 'IN'
    },
    passportNumber: String,
    passportExpiry: Date,
    passportIssueCountry: String,
    frequentFlyerNumbers: [{
      airline: String,
      number: String
    }],
    mealPreference: {
      type: String,
      enum: ['Vegetarian', 'Non-Vegetarian', 'Vegan', 'No Preference']
    },
    seatPreference: {
      type: String,
      enum: ['Window', 'Aisle', 'Middle', 'No Preference']
    }
  },
  isActive: {
    type: Boolean,
    default: true,
    index: true
  },
  isEmailVerified: {
    type: Boolean,
    default: false
  },
  emailVerificationToken: String,
  emailVerificationExpires: Date,
  passwordResetToken: String,
  passwordResetExpires: Date,
  lastLogin: Date,
  loginAttempts: {
    type: Number,
    default: 0
  },
  lockUntil: Date
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes
userSchema.index({ corporateId: 1, email: 1 });
userSchema.index({ corporateId: 1, role: 1 });
userSchema.index({ corporateId: 1, isActive: 1 });
userSchema.index({ ssoProvider: 1, ssoId: 1 });

// Virtual for full name
userSchema.virtual('fullName').get(function() {
  return `${this.name.firstName} ${this.name.lastName}`;
});

// Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password') || !this.password) return next();
  
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// Method to compare passwords
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Method to check if account is locked
userSchema.methods.isLocked = function() {
  return !!(this.lockUntil && this.lockUntil > Date.now());
};

// Method to increment login attempts
userSchema.methods.incLoginAttempts = async function() {
  // If previous lock has expired, restart at 1
  if (this.lockUntil && this.lockUntil < Date.now()) {
    return await this.updateOne({
      $set: { loginAttempts: 1 },
      $unset: { lockUntil: 1 }
    });
  }
  
  const updates = { $inc: { loginAttempts: 1 } };
  
  // Lock account after 5 failed attempts for 2 hours
  if (this.loginAttempts + 1 >= 5 && !this.isLocked()) {
    updates.$set = { lockUntil: Date.now() + 2 * 60 * 60 * 1000 };
  }
  
  return await this.updateOne(updates);
};

// Method to reset login attempts
userSchema.methods.resetLoginAttempts = async function() {
  return await this.updateOne({
    $set: { loginAttempts: 0 },
    $unset: { lockUntil: 1 }
  });
};

module.exports = mongoose.model('User', userSchema);