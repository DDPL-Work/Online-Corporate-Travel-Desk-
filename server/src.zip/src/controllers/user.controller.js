const User = require('../models/User');
const ApiError = require('../utils/ApiError');
const ApiResponse = require('../utils/ApiResponse');
const asyncHandler = require('../utils/asyncHandler');

// @desc    Create new user/employee
// @route   POST /api/v1/users
// @access  Private (Travel Admin)
exports.createUser = asyncHandler(async (req, res) => {
  const userData = {
    ...req.body,
    corporateId: req.user.corporateId,
    isActive: true
  };

  const user = await User.create(userData);

  res.status(201).json(
    new ApiResponse(201, user, 'User created successfully')
  );
});

// @desc    Get all users
// @route   GET /api/v1/users
// @access  Private (Travel Admin)
exports.getAllUsers = asyncHandler(async (req, res) => {
  const { page = 1, limit = 10, role, department, search } = req.query;

  const query = { corporateId: req.user.corporateId };

  if (role) query.role = role;
  if (department) query.department = department;
  if (search) {
    query.$or = [
      { email: new RegExp(search, 'i') },
      { 'name.firstName': new RegExp(search, 'i') },
      { 'name.lastName': new RegExp(search, 'i') }
    ];
  }

  const skip = (parseInt(page) - 1) * parseInt(limit);

  const users = await User.find(query)
    .skip(skip)
    .limit(parseInt(limit))
    .sort({ createdAt: -1 });

  const total = await User.countDocuments(query);

  res.status(200).json(
    new ApiResponse(200, {
      users,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / limit)
      }
    }, 'Users fetched successfully')
  );
});

// @desc    Get single user
// @route   GET /api/v1/users/:id
// @access  Private
exports.getUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id)
    .populate('managerId', 'name email');

  if (!user) {
    throw new ApiError(404, 'User not found');
  }

  res.status(200).json(
    new ApiResponse(200, user, 'User details fetched successfully')
  );
});

// @desc    Update user
// @route   PUT /api/v1/users/:id
// @access  Private (Travel Admin)
exports.updateUser = asyncHandler(async (req, res) => {
  const user = await User.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true, runValidators: true }
  );

  if (!user) {
    throw new ApiError(404, 'User not found');
  }

  res.status(200).json(
    new ApiResponse(200, user, 'User updated successfully')
  );
});

// @desc    Delete user
// @route   DELETE /api/v1/users/:id
// @access  Private (Travel Admin)
exports.deleteUser = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);

  if (!user) {
    throw new ApiError(404, 'User not found');
  }

  user.isActive = false;
  await user.save();

  res.status(200).json(
    new ApiResponse(200, null, 'User deactivated successfully')
  );
});

// @desc    Update user profile
// @route   PUT /api/v1/users/profile
// @access  Private
exports.updateProfile = asyncHandler(async (req, res) => {
  const allowedUpdates = ['name', 'mobile', 'travellerDetails'];
  const updates = {};

  Object.keys(req.body).forEach(key => {
    if (allowedUpdates.includes(key)) {
      updates[key] = req.body[key];
    }
  });

  const user = await User.findByIdAndUpdate(
    req.user.id,
    updates,
    { new: true, runValidators: true }
  );

  res.status(200).json(
    new ApiResponse(200, user, 'Profile updated successfully')
  );
});