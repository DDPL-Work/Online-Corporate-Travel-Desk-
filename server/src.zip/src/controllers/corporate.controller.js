// ==========================================
// FILE: src/controllers/corporate.controller.js
// ==========================================
const Corporate = require('../models/Corporate');
const User = require('../models/User');
const { calculateNextBillingDate } = require('../utils/helpers');
const emailService = require('../services/email.service');
const ApiError = require('../utils/ApiError');
const ApiResponse = require('../utils/ApiResponse');
const asyncHandler = require('../utils/asyncHandler');

// @desc    Create new corporate (Onboarding)
// @route   POST /api/v1/corporate/onboard
// @access  Public (with unique URL)
exports.onboardCorporate = asyncHandler(async (req, res) => {
  const {
    corporateName,
    registeredAddress,
    primaryContact,
    secondaryContact,
    billingDepartment,
    ssoConfig,
    classification,
    creditLimit,
    billingCycle,
    customBillingDays,
    travelPolicy,
    creditTermsNotes
  } = req.body;

  // Check if domain already exists
  const existingCorporate = await Corporate.findOne({ 'ssoConfig.domain': ssoConfig.domain });
  if (existingCorporate) {
    throw new ApiError(400, 'Domain already registered');
  }

  // Create corporate
  const corporate = await Corporate.create({
    corporateName,
    registeredAddress,
    primaryContact,
    secondaryContact,
    billingDepartment,
    ssoConfig: {
      ...ssoConfig,
      verified: false
    },
    classification,
    creditLimit: classification === 'postpaid' ? creditLimit : 0,
    billingCycle,
    customBillingDays,
    travelPolicy,
    creditTermsNotes,
    status: 'pending'
  });

  res.status(201).json(
    new ApiResponse(201, corporate, 'Corporate onboarding initiated. Awaiting verification.')
  );
});

// @desc    Approve corporate onboarding
// @route   PUT /api/v1/corporate/:id/approve
// @access  Private (Super Admin only)
exports.approveCorporate = asyncHandler(async (req, res) => {
  const corporate = await Corporate.findById(req.params.id);

  if (!corporate) {
    throw new ApiError(404, 'Corporate not found');
  }

  if (corporate.status !== 'pending') {
    throw new ApiError(400, 'Corporate is not in pending status');
  }

  corporate.status = 'active';
  corporate.onboardedAt = new Date();
  corporate.onboardedBy = req.user.id;
  corporate.ssoConfig.verified = true;
  corporate.ssoConfig.verifiedAt = new Date();
  corporate.nextBillingDate = calculateNextBillingDate(corporate.billingCycle, corporate.customBillingDays);

  await corporate.save();

  // Create travel admin user
  const travelAdmin = await User.create({
    email: corporate.primaryContact.email,
    name: {
      firstName: corporate.primaryContact.name.split(' ')[0],
      lastName: corporate.primaryContact.name.split(' ').slice(1).join(' ') || 'Admin'
    },
    mobile: corporate.primaryContact.mobile,
    corporateId: corporate._id,
    role: 'travelAdmin',
    isActive: true
  });

  // Send onboarding email
  await emailService.sendCorporateOnboarding(corporate, corporate.primaryContact.email);

  res.status(200).json(
    new ApiResponse(200, corporate, 'Corporate approved and activated successfully')
  );
});

// @desc    Get all corporates
// @route   GET /api/v1/corporate
// @access  Private (Super Admin)
exports.getAllCorporates = asyncHandler(async (req, res) => {
  const { page = 1, limit = 10, status, classification, search } = req.query;

  const query = {};
  if (status) query.status = status;
  if (classification) query.classification = classification;
  if (search) {
    query.$or = [
      { corporateName: new RegExp(search, 'i') },
      { 'primaryContact.email': new RegExp(search, 'i') }
    ];
  }

  const skip = (parseInt(page) - 1) * parseInt(limit);

  const corporates = await Corporate.find(query)
    .skip(skip)
    .limit(parseInt(limit))
    .sort({ createdAt: -1 });

  const total = await Corporate.countDocuments(query);

  res.status(200).json(
    new ApiResponse(200, {
      corporates,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / limit)
      }
    }, 'Corporates fetched successfully')
  );
});

// @desc    Get single corporate
// @route   GET /api/v1/corporate/:id
// @access  Private
exports.getCorporate = asyncHandler(async (req, res) => {
  const corporate = await Corporate.findById(req.params.id);

  if (!corporate) {
    throw new ApiError(404, 'Corporate not found');
  }

  res.status(200).json(
    new ApiResponse(200, corporate, 'Corporate details fetched successfully')
  );
});

// @desc    Update corporate
// @route   PUT /api/v1/corporate/:id
// @access  Private
exports.updateCorporate = asyncHandler(async (req, res) => {
  const corporate = await Corporate.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true, runValidators: true }
  );

  if (!corporate) {
    throw new ApiError(404, 'Corporate not found');
  }

  res.status(200).json(
    new ApiResponse(200, corporate, 'Corporate updated successfully')
  );
});

// @desc    Suspend/Activate corporate
// @route   PATCH /api/v1/corporate/:id/toggle-status
// @access  Private (Super Admin)
exports.toggleCorporateStatus = asyncHandler(async (req, res) => {
  const corporate = await Corporate.findById(req.params.id);

  if (!corporate) {
    throw new ApiError(404, 'Corporate not found');
  }

  corporate.isActive = !corporate.isActive;
  corporate.status = corporate.isActive ? 'active' : 'suspended';
  await corporate.save();

  res.status(200).json(
    new ApiResponse(200, corporate, `Corporate ${corporate.isActive ? 'activated' : 'suspended'} successfully`)
  );
}); 