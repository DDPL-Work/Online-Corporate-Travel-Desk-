
// ==========================================
// FILE: src/routes/corporate.routes.js
// ==========================================
const express = require('express');
const router = express.Router();
const corporateController = require('../controllers/corporate.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');
const { validate } = require('../middlewares/validate.middleware');
const { corporateValidation } = require('../validations');
const { uploadMultiple } = require('../middlewares/upload.middleware');

router.post('/onboard', 
  uploadMultiple, 
  validate, 
  corporateValidation.corporateOnboarding, 
  corporateController.onboardCorporate
);

router.use(protect);

router.get('/', authorize('superAdmin'), corporateController.getAllCorporates);
router.get('/:id', corporateController.getCorporate);
router.put('/:id', authorize('superAdmin', 'travelAdmin'), validate, corporateValidation.updateCorporate, corporateController.updateCorporate);
router.put('/:id/approve', authorize('superAdmin'), corporateController.approveCorporate);
router.patch('/:id/toggle-status', authorize('superAdmin'), corporateController.toggleCorporateStatus);

module.exports = router;