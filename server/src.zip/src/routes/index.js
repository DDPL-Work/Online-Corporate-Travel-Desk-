const express = require('express');
const router = express.Router();

const authRoutes = require('./auth.routes');
const corporateRoutes = require('./corporate.routes');
const bookingRoutes = require('./booking.routes');
const approvalRoutes = require('./approval.routes');
const flightRoutes = require('./flight.routes');
const hotelRoutes = require('./hotel.routes');
const dashboardRoutes = require('./dashboard.routes');
const walletRoutes = require('./wallet.routes');
const voucherRoutes = require('./voucher.routes');
const userRoutes = require('./user.routes');

router.use('/auth', authRoutes);
router.use('/corporate', corporateRoutes);
router.use('/bookings', bookingRoutes);
router.use('/approvals', approvalRoutes);
router.use('/flights', flightRoutes);
router.use('/hotels', hotelRoutes);
router.use('/dashboard', dashboardRoutes);
router.use('/wallet', walletRoutes);
router.use('/vouchers', voucherRoutes);
router.use('/users', userRoutes);

// API documentation route
router.get('/', (req, res) => {
  res.json({
    message: 'Corporate Travel Desk API',
    version: '1.0.0',
    endpoints: {
      auth: '/api/v1/auth',
      corporate: '/api/v1/corporate',
      bookings: '/api/v1/bookings',
      approvals: '/api/v1/approvals',
      flights: '/api/v1/flights',
      hotels: '/api/v1/hotels',
      dashboard: '/api/v1/dashboard',
      wallet: '/api/v1/wallet',
      vouchers: '/api/v1/vouchers',
      users: '/api/v1/users'
    }
  });
});

module.exports = router;

// @desc    Get all bookings
// @route   GET /api/v1/bookings
// @access  Private
exports.getAllBookings = asyncHandler(async (req, res) => {
  const { page = 1, limit = 10, status, bookingType, dateFrom, dateTo } = req.query;

  const query = { corporateId: req.user.corporateId };

  // Role-based filtering
  if (req.user.role === 'employee') {
    query.userId = req.user.id;
  }

  if (status) query.status = status;
  if (bookingType) query.bookingType = bookingType;
  if (dateFrom || dateTo) {
    query.createdAt = {};
    if (dateFrom) query.createdAt.$gte = new Date(dateFrom);
    if (dateTo) query.createdAt.$lte = new Date(dateTo);
  }

  const skip = (parseInt(page) - 1) * parseInt(limit);

  const bookings = await Booking.find(query)
    .populate('userId', 'name email')
    .skip(skip)
    .limit(parseInt(limit))
    .sort({ createdAt: -1 });

  const total = await Booking.countDocuments(query);

  res.status(200).json(
    new ApiResponse(200, {
      bookings,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / limit)
      }
    }, 'Bookings fetched successfully')
  );
});

// @desc    Get single booking
// @route   GET /api/v1/bookings/:id
// @access  Private
exports.getBooking = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id)
    .populate('userId', 'name email mobile')
    .populate('corporateId', 'corporateName')
    .populate('approvalId');

  if (!booking) {
    throw new ApiError(404, 'Booking not found');
  }

  // Check authorization
  if (req.user.role === 'employee' && booking.userId.toString() !== req.user.id) {
    throw new ApiError(403, 'Not authorized to view this booking');
  }

  res.status(200).json(
    new ApiResponse(200, booking, 'Booking details fetched successfully')
  );
});

// @desc    Cancel booking
// @route   POST /api/v1/bookings/:id/cancel
// @access  Private
exports.cancelBooking = asyncHandler(async (req, res) => {
  const { reason } = req.body;
  const booking = await Booking.findById(req.params.id);

  if (!booking) {
    throw new ApiError(404, 'Booking not found');
  }

  if (booking.userId.toString() !== req.user.id && req.user.role !== 'travelAdmin') {
    throw new ApiError(403, 'Not authorized to cancel this booking');
  }

  if (!['confirmed', 'approved'].includes(booking.status)) {
    throw new ApiError(400, 'Only confirmed or approved bookings can be cancelled');
  }

  booking.status = 'cancelled';
  booking.cancellationDetails = {
    cancelledAt: new Date(),
    cancelledBy: req.user.id,
    reason,
    refundAmount: booking.pricing.totalAmount * 0.8, // 80% refund example
    cancellationCharges: booking.pricing.totalAmount * 0.2,
    refundStatus: 'pending'
  };

  await booking.save();

  res.status(200).json(
    new ApiResponse(200, booking, 'Booking cancelled successfully')
  );
});