// ==========================================
// FILE: src/routes/dashboard.routes.js
// ==========================================
const express = require('express');
const router = express.Router();
const dashboardController = require('../controllers/dashboard.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

router.use(protect);

router.get('/employee', authorize('employee'), dashboardController.getEmployeeDashboard);
router.get('/travel-admin', authorize('travelAdmin'), dashboardController.getTravelAdminDashboard);
router.get('/super-admin', authorize('superAdmin'), dashboardController.getSuperAdminDashboard);

module.exports = router;