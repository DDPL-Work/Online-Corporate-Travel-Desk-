// ==========================================
// FILE: src/routes/user.routes.js (previously missing)
// ==========================================
const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');
const { validate } = require('../middlewares/validate.middleware');
const { userValidation } = require('../validations');

router.use(protect);

router.put('/profile', userController.updateProfile);

router.use(authorize('travelAdmin', 'superAdmin'));

router.post('/', validate, userValidation.createUser, userController.createUser);
router.get('/', userController.getAllUsers);
router.get('/:id', userController.getUser);
router.put('/:id', validate, userValidation.updateUser, userController.updateUser);
router.delete('/:id', userController.deleteUser);

module.exports = router;