const express = require('express');
const router = express.Router();
const approvalController = require('../controllers/approval.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

router.use(protect);

router.get('/', authorize('manager', 'travelAdmin'), approvalController.getAllApprovals);
router.get('/:id', approvalController.getApproval);
router.post('/:id/approve', authorize('manager', 'travelAdmin'), approvalController.approveRequest);
router.post('/:id/reject', authorize('manager', 'travelAdmin'), approvalController.rejectRequest);

module.exports = router;