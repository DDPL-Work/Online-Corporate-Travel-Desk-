const express = require('express');
const router = express.Router();
const flightController = require('../controllers/flight.controller');
const { protect, checkCorporateStatus } = require('../middlewares/auth.middleware');
const { validate } = require('../middlewares/validate.middleware');
const { bookingValidation } = require('../validations');
const { searchLimiter } = require('../middlewares/rateLimit.middleware');

router.use(protect);
router.use(checkCorporateStatus);

router.post('/search', searchLimiter, validate, bookingValidation.searchFlight, flightController.searchFlights);
router.post('/fare-quote', flightController.getFareQuote);
router.post('/fare-rules', flightController.getFareRules);

module.exports = router;