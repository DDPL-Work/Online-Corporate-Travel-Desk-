// ==========================================
// FILE: src/routes/hotel.routes.js
// ==========================================
const express = require('express');
const router = express.Router();
const hotelController = require('../controllers/hotel.controller');
const { protect, checkCorporateStatus } = require('../middlewares/auth.middleware');
const { validate } = require('../middlewares/validate.middleware');
const { bookingValidation } = require('../validations');
const { searchLimiter } = require('../middlewares/rateLimit.middleware');

router.use(protect);
router.use(checkCorporateStatus);

router.post('/search', searchLimiter, validate, bookingValidation.searchHotel, hotelController.searchHotels);
router.get('/:hotelCode', hotelController.getHotelDetails);

module.exports = router;