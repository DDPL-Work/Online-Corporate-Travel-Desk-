// ==========================================
// FILE: src/routes/voucher.routes.js
// ==========================================
const express = require('express');
const router = express.Router();
const voucherController = require('../controllers/voucher.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

router.use(protect);
router.use(authorize('travelAdmin'));

router.post('/', voucherController.createOfflineVoucher);
router.get('/', voucherController.getAllVouchers);
router.get('/:id', voucherController.getVoucher);

module.exports = router;