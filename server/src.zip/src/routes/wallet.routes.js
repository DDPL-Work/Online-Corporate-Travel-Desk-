// ==========================================
// FILE: src/routes/wallet.routes.js
// ==========================================
const express = require('express');
const router = express.Router();
const walletController = require('../controllers/wallet.controller');
const { protect, authorize } = require('../middlewares/auth.middleware');

router.use(protect);
router.use(authorize('travelAdmin', 'superAdmin'));

router.get('/balance', walletController.getWalletBalance);
router.get('/transactions', walletController.getWalletTransactions);
router.post('/recharge', walletController.initiateRecharge);
router.post('/verify-payment', walletController.verifyPayment);

module.exports = router;