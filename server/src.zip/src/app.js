const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const compression = require("compression");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");
const session = require("express-session");
const passport = require("passport");

const config = require("./config");
const routes = require("./routes/index.js");
const { errorMiddleware } = require("./middleware/error.middleware.js");
const rateLimitMiddleware = require("./middleware/rateLimit.middleware.js");
const logger = require("./utils/logger.js");
const cronJobs = require("./jobs");

const app = express();

app.set("trust proxy", 1);

app.use(
  helmet({
    contentSecurityPolicy: false,
  })
);

app.use(
  cors({
    origin: [config.frontend.url, config.frontend.adminUrl],
    credentials: true,
  })
);

app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(cookieParser());

app.use(compression());

app.use(
  session({
    secret: config.session.secret,
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: config.env === "production",
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000,
    },
  })
);

app.use(passport.initialize());
app.use(passport.session());

app.use(
  config.env === "development"
    ? morgan("dev")
    : morgan("combined")
);

app.use("/api", rateLimitMiddleware.apiLimiter);

app.use("/uploads", express.static("uploads"));

app.use(`/api/${config.api.version}`, routes);

app.get("/health", (req, res) => {
  res.status(200).json({ status: "OK", env: config.env });
});

// Error handler
app.use(errorMiddleware);

if (config.cronJobs.enabled) {
  cronJobs.start();
  logger.info("✓ Cron Jobs Started");
}

module.exports = app;
