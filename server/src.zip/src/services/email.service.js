const nodemailer = require('nodemailer');
const handlebars = require('handlebars');
const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

class EmailService {
  constructor() {
    this.transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT),
      secure: process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASSWORD
      }
    });
  }

  async sendEmail(options) {
    try {
      const mailOptions = {
        from: `${process.env.EMAIL_FROM_NAME} <${process.env.EMAIL_FROM}>`,
        to: options.to,
        subject: options.subject,
        html: options.html,
        attachments: options.attachments || []
      };

      const info = await this.transporter.sendMail(mailOptions);
      logger.info(`Email sent: ${info.messageId}`);
      return info;
    } catch (error) {
      logger.error('Email sending error:', error);
      throw error;
    }
  }

  async sendBookingConfirmation(booking, user) {
    const subject = `Booking Confirmation - ${booking.bookingReference}`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Booking Confirmed!</h2>
        <p>Dear ${user.fullName},</p>
        <p>Your booking has been confirmed successfully.</p>
        <div style="background: #f5f5f5; padding: 15px; margin: 20px 0;">
          <h3>Booking Details</h3>
          <p><strong>Booking Reference:</strong> ${booking.bookingReference}</p>
          <p><strong>Type:</strong> ${booking.bookingType}</p>
          <p><strong>Amount:</strong> ₹${booking.pricing.totalAmount}</p>
        </div>
        <p>Please find your booking details attached.</p>
        <p>Thank you for choosing our service.</p>
      </div>
    `;

    return await this.sendEmail({
      to: user.email,
      subject,
      html
    });
  }

  async sendApprovalRequest(approval, requester, approver) {
    const subject = `Travel Approval Request - ${approval.bookingDetails.destination}`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Travel Approval Request</h2>
        <p>Dear ${approver.fullName},</p>
        <p>${requester.fullName} has requested approval for the following travel:</p>
        <div style="background: #f5f5f5; padding: 15px; margin: 20px 0;">
          <p><strong>Destination:</strong> ${approval.bookingDetails.destination}</p>
          <p><strong>Travel Date:</strong> ${new Date(approval.bookingDetails.travelDate).toLocaleDateString()}</p>
          <p><strong>Amount:</strong> ₹${approval.bookingDetails.amount}</p>
          <p><strong>Purpose:</strong> ${approval.bookingDetails.purposeOfTravel}</p>
        </div>
        <p>Please login to review and approve/reject this request.</p>
        <a href="${process.env.FRONTEND_URL}/approvals/${approval._id}" 
           style="background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; display: inline-block; margin: 10px 0;">
          Review Request
        </a>
      </div>
    `;

    return await this.sendEmail({
      to: approver.email,
      subject,
      html
    });
  }

  async sendApprovalNotification(approval, requester, status) {
    const subject = `Travel Request ${status} - ${approval.bookingDetails.destination}`;
    const statusColor = status === 'Approved' ? '#4CAF50' : '#f44336';
    
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: ${statusColor}">Travel Request ${status}</h2>
        <p>Dear ${requester.fullName},</p>
        <p>Your travel request has been <strong>${status.toLowerCase()}</strong>.</p>
        <div style="background: #f5f5f5; padding: 15px; margin: 20px 0;">
          <p><strong>Destination:</strong> ${approval.bookingDetails.destination}</p>
          <p><strong>Travel Date:</strong> ${new Date(approval.bookingDetails.travelDate).toLocaleDateString()}</p>
          ${approval.approverComments ? `<p><strong>Comments:</strong> ${approval.approverComments}</p>` : ''}
        </div>
        ${status === 'Approved' ? '<p>You can now proceed to complete your booking.</p>' : ''}
      </div>
    `;

    return await this.sendEmail({
      to: requester.email,
      subject,
      html
    });
  }

  async sendCorporateOnboarding(corporate, adminEmail) {
    const subject = 'Welcome to Corporate Travel Desk';
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2>Welcome to Corporate Travel Desk!</h2>
        <p>Dear ${corporate.primaryContact.name},</p>
        <p>Your corporate account has been successfully created and activated.</p>
        <div style="background: #f5f5f5; padding: 15px; margin: 20px 0;">
          <h3>Account Details</h3>
          <p><strong>Corporate Name:</strong> ${corporate.corporateName}</p>
          <p><strong>Classification:</strong> ${corporate.classification}</p>
          <p><strong>SSO Domain:</strong> ${corporate.ssoConfig.domain}</p>
        </div>
        <p>Your employees can now login using their ${corporate.ssoConfig.type} accounts.</p>
        <p>Please contact us if you have any questions.</p>
      </div>
    `;

    return await this.sendEmail({
      to: adminEmail,
      subject,
      html
    });
  }

  async sendCreditAlert(corporate, utilizationPercent) {
    const subject = `Credit Alert: ${utilizationPercent}% Utilized`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #ff9800;">Credit Utilization Alert</h2>
        <p>Dear ${corporate.primaryContact.name},</p>
        <p>This is to inform you that your corporate account has utilized ${utilizationPercent}% of the credit limit.</p>
        <div style="background: #fff3cd; padding: 15px; margin: 20px 0; border-left: 4px solid #ff9800;">
          <p><strong>Credit Limit:</strong> ₹${corporate.creditLimit.toLocaleString()}</p>
          <p><strong>Used:</strong> ₹${corporate.currentCredit.toLocaleString()}</p>
          <p><strong>Available:</strong> ₹${(corporate.creditLimit - corporate.currentCredit).toLocaleString()}</p>
        </div>
        <p>Please contact us to increase your credit limit or clear pending dues.</p>
      </div>
    `;

    return await this.sendEmail({
      to: corporate.primaryContact.email,
      subject,
      html
    });
  }
}

module.exports = new EmailService();